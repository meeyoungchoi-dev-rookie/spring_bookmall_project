package com.bookkurly.bookmall.admin.adimaccount.service;

import com.bookkurly.bookmall.admin.adimaccount.entity.BookMallManager;

public interface BookMallMangerService {
	public BookMallManager logincheck(BookMallManager bm);

}
