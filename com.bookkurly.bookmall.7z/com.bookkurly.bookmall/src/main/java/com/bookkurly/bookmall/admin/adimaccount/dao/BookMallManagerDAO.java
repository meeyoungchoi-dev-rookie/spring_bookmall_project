package com.bookkurly.bookmall.admin.adimaccount.dao;

import com.bookkurly.bookmall.admin.adimaccount.entity.BookMallManager;

public interface BookMallManagerDAO {

	public BookMallManager selectOne(BookMallManager bm);
}
